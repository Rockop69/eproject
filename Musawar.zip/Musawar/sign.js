// Button to open the modal
// <button onclick="document.getElementById('id01').style.display='block'">Sign Up</button>
// The Modal (contains the Sign Up form) 

document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector(".contact-form form");
  
    form.addEventListener("submit", function (event) {
        event.preventDefault();
  
        const name = form.querySelector("input[type='text']");
        const email = form.querySelector("input[type='email']");
        const message = form.querySelector("textarea");
  
        if (validateForm(name, email, message)) {
            alert("Thank you! Your message has been sent successfully.");
            form.reset(); 
        }
    });
  
    function validateForm(name, email, message) {
        if (name.value.trim() === "") {
            alert("Please enter your name.");
            name.focus();
            return false;
        }
  
        if (email.value.trim() === "") {
            alert("Please enter your email.");
            email.focus();
            return false;
        }
  
        if (!isValidEmail(email.value)) {
            alert("Please enter a valid email address.");
            email.focus();
            return false;
        }
  
        if (message.value.trim() === "") {
            alert("Please enter your message.");
            message.focus();
            return false;
        }
  
        return true;
    }
  
    function isValidEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }
  });